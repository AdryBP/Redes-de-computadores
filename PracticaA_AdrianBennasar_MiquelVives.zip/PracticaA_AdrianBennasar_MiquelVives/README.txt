Hemos detectado que si se abre el PDF con el navegador "Mozilla Firefox" los hipervinculos a los Excels no funcionan.

Tanto con Google Chrome como con Microsoft Edge está asegurado que funcionan.

Coordialmente, Adrian Bennasar y Miquel Vives.